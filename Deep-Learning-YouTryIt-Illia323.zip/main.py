from DeepLearning.deepSolution import main

main()